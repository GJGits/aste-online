<noscript>
<div class="bd-callout" style="border-left-color: red;">
        <h5>Javascript disabilitato</h5>
        Disabilitando Javascript le funzionalit&agrave; dell'applicazione sono ridotte.
        <p>Possibili conseguenze:</p>
        <ul>
            <li>Mancata visualizzazione dei messaggi di errore</li>
            <li>Impossibilit&agrave; a compiere azioni</li>
        </ul> 
    </div>
</noscript>