<?php
  class Example
  {
    var $name = "Michael";   // Same as public but deprecated
    public $age = 23;        // Public property
    protected $usercount;    // Protected property
  
    private function admin() // Private method
    {
      // Admin code goes here
    }
  }
?>
