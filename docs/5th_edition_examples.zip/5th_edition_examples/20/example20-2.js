function S(i)
{
  return O(i).style
}
