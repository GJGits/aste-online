<html>
  <head>
    <title>Exercise 1</title>
  </head>
  <body>
    <h1>Example with PHP</h1>
    <p>
    <?php
	$a = "Charlie Brown";
	$b = 18;
	$c = $b+77;
	echo "I like $a </p>";
	echo "<p>Value of c: $c </p>";
    ?>
  </body>
</html>
