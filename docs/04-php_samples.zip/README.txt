
In this archive you can find the examples referenced in the php slides. In order to run these examples, put the php_samples directory into the XAMPP htdocs directory and run the apache web server (and the mysql server, when necessary).
